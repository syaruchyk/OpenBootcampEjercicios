cadena = "Hola mundo!"
print(cadena)
