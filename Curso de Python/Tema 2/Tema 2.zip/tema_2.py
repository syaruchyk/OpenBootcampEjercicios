cadena = "Hola mundo!"
print(cadena)
cadena = "Hola mundo! (modificado)"
print (cadena)
